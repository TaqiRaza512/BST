#pragma once
#include<queue>
#include<vector>
using namespace std;
class BST
{
	friend class Node;
private:
	class Node
	{
		friend class BST;
	private:
		int Data;
		Node* Right;
		Node* Left;
		Node* Parent;
	public:
		Node(int d=0, Node* R= nullptr,Node* L= nullptr,Node* P=nullptr)
		{
			Data = d;
			Right = R;
			Left = L;
			Parent = P;
		}
	};
	Node* Root;
	void InsertValue(int value, Node*& Root,Node* Parent);
	void PrintLNR(Node* Root);
	void PrintNLR(Node* Root);
	void PrintLRN(Node* Root);
	void PrintRLN(Node* Root);
	void PrintLeaves(Node*Root);
	void NodesAtDistanceK(Node* Root, int K);
	void PrimeCounts(Node* Root,int &count);
	void EvenCounts(Node* Root, int& count);
	int Height(Node* Root);
	bool PictoriallyWise(Node* Root, Node* BRoot);
	void InsertValuesInAscOrder(Node* Root, vector<int>&VS);
	int TreeMinimum(Node*Root);
	int TreeMaximum(Node* Root);
	bool IsBalancedTree(Node*Root);
	Node*& ClosestLeaf(queue<Node*>& Vs);
	Node*& FarthestLeaf(queue<Node*>& Vs,Node*& Temp);
	void CountingInternalNodes(Node* Root, int& count);
	void CountingLeaves(Node* Root, int& count);
	void CountingOneBranchOut(Node* Root, int& count);


public:
	BST(Node* R = nullptr);
	void InsertValue(int value);
	void PrintLNR();
	void PrintNLR();
	void PrintLRN();
	void PrintRLN();
	void PrintLeaves();
	void NodesAtDistanceK(int K);
	int PrimeCounts();
	int EvenCounts();
	int Height();
	bool PictoriallyWise(BST Tree);
	bool ValueWise(BST Tree);
	int TreeMinimum();
	int TreeMaximum();
	bool IsBalancedTree();
	int  ClosestLeaf();
	int  FarthestLeaf();
	void ClosestPathToLeaf();
	Node*& ClosestLeafForPath();
	Node*& FarthestLeafForPath();
	void FarthestPathToLeaf();
	bool IsLeaf(Node* Temp);
	int CountingInternalNodes();
	int CountingLeaves();
	int CountingOneBranchOut();



};

