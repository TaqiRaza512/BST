#include "BST.h"
#include<iostream>
#include<queue>
#include<vector>
using namespace std;

BST::BST(Node*R)
{
	Root = R;
}

void BST::InsertValue(int value)
{
	InsertValue(value, Root,nullptr);
}
void BST::InsertValue(int value, Node*& Root, Node* Parent)
{
	if (!Root)
	{
		Root = new Node(value);
		Root->Parent = Parent;
		return;
	}
	if (value < Root->Data)
		InsertValue(value, Root->Left, Root);

	if (value > Root->Data)
		InsertValue(value, Root->Right,Root);
}

void BST::PrintLNR()
{
	PrintLNR(Root);
}
void BST::PrintLNR(Node * Root)
{

	if (!Root)
		return;

	PrintLNR(Root->Left);
	cout << Root->Data << "  ";
	PrintLNR(Root->Right);
}

void BST::PrintNLR()
{
	PrintNLR(Root);
}
void BST::PrintNLR(Node* Root)
{

	if (!Root)
		return;

	cout << Root->Data << "  ";
	PrintNLR(Root->Left);
	PrintNLR(Root->Right);
}

void BST::PrintLRN()
{
	PrintLRN(Root);
}
void BST::PrintLRN(Node* Root)
{

	if (!Root)
		return;

	PrintLRN(Root->Left);
	PrintLRN(Root->Right);
	cout << Root->Data << "  ";
}

void BST::PrintRLN()
{
	PrintRLN(Root);
}
void BST::PrintRLN(Node* Root)
{

	if (!Root)
		return;

	PrintRLN(Root->Right);
	PrintRLN(Root->Left);
	cout << Root->Data << "  ";
}

void BST::PrintLeaves()
{
	PrintLeaves(Root);
}
void BST::PrintLeaves(Node*Root)
{

	if (!Root)
		return;

	PrintLeaves(Root->Left);
	if (!Root->Left and !Root->Right)
		cout << Root->Data<<"  ";
	PrintLeaves(Root->Right);

}

void BST::NodesAtDistanceK(int K)
{

	NodesAtDistanceK(Root, K);

}
void  BST::NodesAtDistanceK(Node* Root, int K)
{
	queue<Node*>StoringNodes;
	Node* Temp=nullptr;
	StoringNodes.push(Root);
	StoringNodes.push(nullptr);
	int Distance = 0;
	while (true)
	{
		if (Distance==K)
			break;
		else
		{
			bool IsInsert;
			while (StoringNodes.front())
			{
				Temp = StoringNodes.front();
				if (Temp->Left)
				{
					IsInsert = true;
					StoringNodes.push(Temp->Left);

				}
				if (Temp->Right)
				{
					IsInsert = true;
					StoringNodes.push(Temp->Right);
				}
				StoringNodes.pop();

				if (StoringNodes.size() == 0)
				{
					break;
				}
			}
			if (IsInsert)
			{
				StoringNodes.push(nullptr);
				IsInsert = false;
			}
			if(!StoringNodes.empty())
				StoringNodes.pop();
		}
		Distance++;
	}
	if (!StoringNodes.empty())
	{
		while (StoringNodes.front())
		{
			cout << StoringNodes.front()->Data;
			cout << "  ";
			StoringNodes.pop();
			if (StoringNodes.empty())
				break;
		}
	}
}

int BST::PrimeCounts()
{
	int count=0;
	PrimeCounts(Root,count);
	return count;
}
bool IsPrime(int val)
{
	int count = 0;
		
	for (int ri=1;ri<=val;ri++)
	{
		if (val % ri == 0)
			count++;

	}
	if (count==2)
	{
		return true;
	}
	return false;
}
void BST::PrimeCounts(Node*Root,int& count)
{
	if (!Root)
		return;
	PrimeCounts(Root->Left,count);
	if (IsPrime(Root->Data))
	{
		count++;
	}
	PrimeCounts(Root->Right,count);

}

int BST::EvenCounts()
{
	int count = 0;
	EvenCounts(Root, count);
	return count;

}
void BST::EvenCounts(Node* Root, int& count)
{

	if (!Root)
		return;
	EvenCounts(Root->Left, count);
	if (Root->Data%2==0)
	{
		count++;
	}
	EvenCounts(Root->Right, count);
}

int Max(int a,int b)
{
	if (a > b)
		return a;
	return b;
}
int BST::Height(Node* Root)
{
	if (!Root)
		return 0;

	return 1+Max(Height(Root->Left),Height(Root->Right));
}
int  BST::Height()
{
	return Height(Root);
}

bool BST::PictoriallyWise(BST Tree)
{
	return PictoriallyWise(Root,Tree.Root);
}
bool BST::PictoriallyWise(Node* Root, Node* BRoot)
{
	if (Root->Left and BRoot->Left)
	{
		return true;
	}
	else if(!(!Root->Left and !BRoot->Left))
	{
		return false;
	}
	if (Root->Right and BRoot->Right)
	{
		return true;
	}
	else if (!(!Root->Right and !BRoot->Right))
	{
		return false;
	}

	return PictoriallyWise(Root->Right, Root->Right)&& PictoriallyWise(Root->Left, Root->Left);
}

void BST::InsertValuesInAscOrder(BST::Node* Root, vector<int>&VS)
{
	if (!Root)
		return;

	InsertValuesInAscOrder(Root->Left, VS);
	VS.push_back(Root->Data);
	InsertValuesInAscOrder(Root->Right, VS);

}

bool BST::ValueWise(BST Tree)
{
	vector<int>FirstTree;
	vector<int>SecondTree;
	InsertValuesInAscOrder(this->Root,FirstTree);
	InsertValuesInAscOrder(Tree.Root,SecondTree);
	if (FirstTree == SecondTree)
	{
		return true;
	}
	return false;
}

int BST::TreeMinimum(Node*Root)
{
	if (!Root->Left)
		return Root->Data;

	TreeMinimum(Root->Left);
}
int BST::TreeMaximum(Node* Root)
{
	if (!Root->Right)
		return Root->Data;
	TreeMaximum(Root->Right);
}

int BST::TreeMinimum()
{
	return TreeMinimum(Root);
}
int BST::TreeMaximum()
{
	return TreeMaximum(Root);
}

bool BST::IsBalancedTree()
{
	return IsBalancedTree(Root);
}
bool BST::IsBalancedTree(Node* Root)
{
	int Hl = 0,Hr=0;

	if (!Root)
	{
		return true;
	}
	Hl = Height(Root->Left);
	Hr = Height(Root->Right);

	if (abs(Hl - Hr) > 1)
		return false;

	return IsBalancedTree(Root->Left) && IsBalancedTree(Root->Right);
}



int  BST::ClosestLeaf()
{

	queue<Node*>Vs;
	Vs.push(Root);
	Vs.push(nullptr);
	Node*Temp= ClosestLeaf(Vs);
	return Temp->Data;
}
BST::Node*&  BST::ClosestLeafForPath()
{

	queue<Node*>Vs;
	Vs.push(Root);
	Vs.push(nullptr);
	return ClosestLeaf(Vs);
}
BST::Node*& BST::ClosestLeaf(queue<Node*>&Vs)
{
	if (!Vs.front())
	{
		Vs.pop();
	}
	else if(!Vs.front() and Vs.size() == 1)
	{
		return Vs.front();
	}
	else if(Vs.front())
	{
		while (Vs.front())
		{
			if (Vs.front()->Left)
			{
				Vs.push(Vs.front()->Left);

				if (!Vs.front()->Left->Left and !Vs.front()->Left->Right)
				{
					return Vs.front()->Left;
				}
			}
			if (Vs.front()->Right)
			{
				Vs.push(Vs.front()->Right);

				if (!Vs.front()->Right->Left and !Vs.front()->Right->Right)
				{
					return Vs.front()->Right;
				}
			}
			Vs.pop();
		}
	}
	ClosestLeaf(Vs);
}
void BST::ClosestPathToLeaf()
{
	Node* Temp = ClosestLeafForPath();
	cout << endl;
	while (Temp)
	{
		cout << "==>" << Temp->Data ;
		Temp = Temp->Parent;
	}
}

BST::Node*& BST::FarthestLeaf(queue<Node*>& Vs, Node*& Temp)
{
	if (Vs.size()== 0)
	{
		return Temp;
	}
	if (!Vs.front() and Vs.size() == 1)
	{
		return Temp;
	}
	else if (!Vs.front())
	{
		Vs.pop();
	}
	else if (Vs.front())
	{
		while (Vs.front())
		{
			if (Vs.front()->Left)
			{
				Vs.push(Vs.front()->Left);

				if (!Vs.front()->Left->Left and !Vs.front()->Left->Right)
				{
					Temp = Vs.front()->Left;
				}
			}
			if (Vs.front()->Right)
			{
				Vs.push(Vs.front()->Right);

				if (!Vs.front()->Right->Left and !Vs.front()->Right->Right)
				{
					Temp=Vs.front()->Right;
				}
			}
			Vs.pop();
			if (Vs.size()==0)
			{
				return Temp;
			}
		}
	}
	FarthestLeaf(Vs,Temp);
}
BST::Node*& BST::FarthestLeafForPath()
{

	queue<Node*>Vs;
	Node* Temp;
	Vs.push(Root);
	Vs.push(nullptr);
	return FarthestLeaf(Vs, Temp);
}
void BST::FarthestPathToLeaf()
{
	Node* Temp = FarthestLeafForPath();
	cout << endl;
	while (Temp)
	{
		cout << "==>" << Temp->Data;
		Temp = Temp->Parent;
	}
}
int  BST::FarthestLeaf()
{

	queue<Node*>Vs;
	Node* Temp;
	Vs.push(Root);
	Vs.push(nullptr);
	Temp= FarthestLeaf(Vs,Temp);
	return Temp->Data;
}

bool BST::IsLeaf(Node* Temp)
{
	if (!Temp->Left and !Temp->Right)
		return true;
	return false;
}
int BST::CountingInternalNodes()
{
	int count = 0;
	CountingInternalNodes(Root, count);
	return count;
}
void BST::CountingInternalNodes(Node*Root,int&count)
{
	if (!Root)
		return;

	CountingInternalNodes(Root->Left,count);
	if (!IsLeaf(Root))
	{
		count++;
	}
	CountingInternalNodes(Root->Right,count);
}


int BST::CountingLeaves()
{
	int count = 0;
	CountingLeaves(Root, count);
	return count;
}
void BST::CountingLeaves(Node* Root, int& count)
{
	if (!Root)
		return;

	CountingLeaves(Root->Left, count);
	if (IsLeaf(Root))
	{
		count++;
	}
	CountingLeaves(Root->Right, count);
}

int BST::CountingOneBranchOut()
{

	int count = 0;
	CountingOneBranchOut(Root, count);
	return count;
}
void BST::CountingOneBranchOut(Node* Root, int& count)
{
	if (!Root)
		return;

	CountingOneBranchOut(Root->Left, count);
	if (!IsLeaf(Root) and (Root->Left or Root->Right))
	{
		count++;
	}
	CountingOneBranchOut(Root->Right, count);
}
